import fs from "node:fs";
import java from "file:///home/lmsousa/Documents/Projects/SPeCS/ast-protobuf/node_modules/java/index.js";
import base from "file:///home/lmsousa/.cache/protobuf-production-validation/build-final-20261008/lara-framework/Lara-JS/dist/vitest/weaverEnvironment.js";
const environment = { ...base, async setup(global, options) {
  const overlay = process.env.APP_BUILD_OVERLAY_JAR;
  if (!overlay) throw new Error("APP_BUILD_OVERLAY_JAR is required");
  const marker = process.env.APP_BUILD_ENVIRONMENT_MARKER;
  fs.appendFileSync(marker, JSON.stringify({event: "setup-entry", jvmCreated: java.isJvmCreated(), overlay}) + "\n");
  if (java.isJvmCreated()) throw new Error("Java VM started before app-build overlay registration");
  java.registerClient(() => {
    if (!java.classpath.includes(overlay)) java.classpath.unshift(overlay);
    fs.appendFileSync(marker, JSON.stringify({event: "before-jvm", classpath: java.classpath.slice(0, 8)}) + "\n");
    console.error("APP_BUILD_OVERLAY_PREPENDED " + overlay);
  }, null);
  const result = await base.setup(global, options);
  fs.appendFileSync(marker, JSON.stringify({event: "setup-complete", jvmCreated: java.isJvmCreated(), classpath: java.classpath.slice(0, 8)}) + "\n");
  return result;
} };
export default environment;
